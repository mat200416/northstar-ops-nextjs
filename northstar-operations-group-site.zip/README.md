
# NorthStar Operations Group — Website

This is a ready-to-deploy **Next.js 14 + Tailwind** site.

## How to use

### 1) Put this code on GitHub
- On GitHub, create a new empty repo (public or private).
- Click **Add file → Upload files** and upload everything from this folder.
  - Or upload the ZIP directly and let GitHub extract it.

### 2) Deploy to Vercel
- Go to vercel.com → **New Project** → Import your GitHub repo.
- Accept defaults (Next.js will be auto-detected) and deploy.
- After deploy, in Vercel → **Settings → Domains**, add your custom domain.
- Follow Vercel’s on-screen DNS instructions (it shows the exact records to add in Namecheap).

### 3) Point your Namecheap domain
- In Namecheap → Domain List → Manage → Advanced DNS:
  - Add the DNS records Vercel shows you (A/CNAME). Save.

### 4) Contact form
- In `app/page.tsx`, replace the placeholder Formspree endpoint (`https://formspree.io/f/REPLACE_ME`) with your real endpoint from formspree.io (or switch to an API route later).

### Local development (optional)
```
npm i
npm run dev
# open http://localhost:3000
```
