"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  ArrowRight, CheckCircle2, Building2, FileText,
  Users2, LineChart, ShieldCheck, Phone, Mail, MapPin
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const nav = [
  { id: "services", label: "Services" },
  { id: "process", label: "Process" },
  { id: "cases", label: "Case Studies" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
];

const services = [
  {
    icon: <Building2 className="w-6 h-6" />,
    title: "Sell-Ready Operations",
    desc: "12-24 month readiness: SOPs, KPIs, clean books, and transition plan to maximize exit value.",
    bullets: ["SOP library & training", "Weekly KPI scorecard", "Owner-dependency reduction"],
  },
  {
    icon: <LineChart className="w-6 h-6" />,
    title: "Revenue Systems",
    desc: "Install lead funnels, offer architecture, pricing, and outbound to create consistent deal flow.",
    bullets: ["Offer & pricing design", "CRM + automation stack", "Outbound playbooks"],
  },
  {
    icon: <ShieldCheck className="w-6 h-6" />,
    title: "Acquisition & Turnaround",
    desc: "Buy or partner via seller-finance, fix bookkeeping, convert to recurring cash flow, then refinance.",
    bullets: ["Deal underwriting", "Seller-finance structuring", "90-day turnaround plan"],
  },
];

const tiers = [
  {
    name: "Advisor",
    price: "$3,500/mo",
    tag: "Best for <$2M revenue",
    items: [
      "Weekly strategy call",
      "Scorecard & KPI setup",
      "Light CRM automations",
      "Email support (48h)"
    ],
  },
  {
    name: "Operator",
    price: "$7,500/mo",
    tag: "Hands-on implementation",
    featured: true,
    items: [
      "Bi-weekly working sessions",
      "Pipeline build + outbound",
      "SOPs + reporting templates",
      "Dedicated Slack (same-day)"
    ],
  },
  {
    name: "Exit-Ready",
    price: "$12,500/mo",
    tag: "12-month sell-ready program",
    items: [
      "GAAP cleanup + CFO cadence",
      "Vendor/COGS optimization",
      "Buyer package & data room",
      "On-site quarterly workshops"
    ],
  },
];

const cases = [
  {
    title: "9-Unit Commercial → Triple-Net",
    result: "+$162K/year NOI; refi in 18 months",
    text: "Converted under-managed mixed-use into NNN lease structure, stabilized rents at market, prepped for refi despite weak historicals.",
  },
  {
    title: "Service Contractor → Scorecards",
    result: "+38% gross margin in 120 days",
    text: "Installed job-costing, weekly WIP reviews, and price discipline; added retainer maintenance plans for predictable cash flow.",
  },
  {
    title: "Brokerage → Retainer Studio",
    result: "+$52K MRR in 6 months",
    text: "Repositioned project fees to productized retainers, implemented outbound sequences, and standardized onboarding.",
  },
];

function Section({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <section id={id} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      {children}
    </section>
  );
}

export default function NorthStarSite() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-slate-100">
      <header className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-slate-900/70 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-slate-100/10 grid place-items-center ring-1 ring-slate-700">
              <div className="relative w-5 h-5">
                <div className="absolute inset-0 rotate-45 bg-gradient-to-tr from-slate-200 to-slate-400 rounded-sm" />
                <div className="absolute inset-1 bg-slate-900 rounded-sm" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-1 h-1 bg-slate-300 rounded-full" />
                </div>
              </div>
            </div>
            <div>
              <p className="font-semibold tracking-wide">NorthStar Operations Group</p>
              <p className="text-xs text-slate-400 -mt-1">Turn Operations Into Opportunity</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            {nav.map((n) => (
              <button
                key={n.id}
                onClick={() => scrollTo(n.id)}
                className="text-slate-300 hover:text-white transition"
              >
                {n.label}
              </button>
            ))}
            <a href="#contact">
              <button className="inline-flex items-center justify-center h-10 px-4 rounded-xl bg-slate-100 text-slate-900 hover:bg-white font-medium">
                Get a Consult
              </button>
            </a>
          </nav>
        </div>
      </header>

      <Section id="home">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-6xl font-extrabold leading-tight"
            >
              Build a Company Worth Buying
            </motion.h1>
            <p className="mt-6 text-slate-300 text-lg">
              We help owners of under-managed businesses clean the books, productize services, install scorecards, and create reliable cash flow—
              so you can <span className="text-slate-100 font-semibold">sell, refinance, or scale</span> on your timeline.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a href="#contact">
                <button className="inline-flex items-center justify-center h-12 px-6 rounded-2xl bg-slate-100 text-slate-900 hover:bg-white font-medium text-base">
                  Request a Strategy Call <span className="ml-2 inline-flex"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></span>
                </button>
              </a>
              <a href="#services">
                <button className="inline-flex items-center justify-center h-12 px-6 rounded-2xl bg-slate-800 text-slate-100 hover:bg-slate-700 font-medium text-base">
                  See Services
                </button>
              </a>
            </div>
            <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-slate-400">
              <div><span className="block text-slate-100 text-xl font-bold">90-Day</span> Turnaround Plans</div>
              <div><span className="block text-slate-100 text-xl font-bold">Weekly</span> KPI Scorecards</div>
              <div><span className="block text-slate-100 text-xl font-bold">Seller-Finance</span> Structuring</div>
              <div><span className="block text-slate-100 text-xl font-bold">Exit-Ready</span> Packaging</div>
            </div>
          </div>
          <div className="lg:pl-6">
            <div className="grid grid-cols-2 gap-4">
              {services.map((s, i) => (
                <motion.div
                  key={s.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="bg-slate-900/60 border-slate-800 rounded-2xl shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-slate-100/10 ring-1 ring-slate-800">
                          {s.icon}
                        </div>
                        <h3 className="font-semibold">{s.title}</h3>
                      </div>
                      <p className="mt-3 text-sm text-slate-300">{s.desc}</p>
                      <ul className="mt-3 space-y-2 text-sm">
                        {s.bullets.map((b) => (
                          <li key={b} className="flex items-center gap-2 text-slate-300">
                            <CheckCircle2 className="w-4 h-4 text-slate-200" />
                            {b}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section id="services">
        <div className="max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold">Consulting Services</h2>
          <p className="mt-3 text-slate-300">
            Pricing is transparent. Engagements are month-to-month with a 30-day out. We focus on measurable operating income (OI) gains, not deliverables wallpaper.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          {tiers.map((t) => (
            <Card key={t.name} className={`rounded-2xl border-slate-800 ${t.featured ? "ring-2 ring-slate-300" : ""}`}>
              <CardContent className="p-6">
                <p className="text-xs uppercase tracking-wide text-slate-400">{t.tag}</p>
                <h3 className="mt-1 text-xl font-semibold">{t.name}</h3>
                <p className="mt-2 text-3xl font-bold">{t.price}</p>
                <ul className="mt-4 space-y-2 text-sm">
                  {t.items.map((it) => (
                    <li key={it} className="flex items-center gap-2 text-slate-300"><CheckCircle2 className="w-4 h-4" />{it}</li>
                  ))}
                </ul>
                <a href="#contact">
                  <button className="inline-flex items-center justify-center h-10 px-4 rounded-xl bg-slate-100 text-slate-900 hover:bg-white font-medium w-full mt-6">
                    Book Intro Call
                  </button>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      <Section id="process">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold">Our 90-Day Operating System</h2>
            <p className="mt-3 text-slate-300">
              We install a lightweight, scalable operating system that outlives any single person—including us. Fewer meetings, clearer dashboards, and real ownership by your team.
            </p>
            <div className="mt-6 space-y-4">
              {[
                { t: "Weeks 1-2: Baseline & Scorecard", d: "Financial snapshot, KPI tree, owner time audit, quick wins for margin." },
                { t: "Weeks 3-6: Revenue & Pricing", d: "Offer architecture, price discipline, pipeline build, outbound sequences." },
                { t: "Weeks 7-10: Ops & Delivery", d: "SOPs, job-costing, WIP reviews, vendor optimization, cash gap fixes." },
                { t: "Weeks 11-12: Exit-Ready", d: "Buyer package, data room, CFO cadence, transition plan and timeline." }
              ].map((row) => (
                <div key={row.t} className="flex gap-3">
                  <FileText className="w-5 h-5 mt-1 text-slate-300" />
                  <div>
                    <p className="font-semibold">{row.t}</p>
                    <p className="text-slate-300 text-sm">{row.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <Card className="rounded-2xl border-slate-800 bg-slate-900/60">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">What You’ll See Weekly</h3>
              <ul className="mt-4 space-y-2 text-sm">
                {[
                  "KPI scorecard with trends",
                  "Cash, AR, WIP & pipeline snapshot",
                  "Owner hours → team delegation map",
                  "Risks & blockers with decisions"
                ].map((i) => (
                  <li key={i} className="flex items-center gap-2 text-slate-300"><CheckCircle2 className="w-4 h-4" />{i}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </Section>

      <Section id="cases">
        <div className="max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold">Selected Case Studies</h2>
          <p className="mt-3 text-slate-300">Representative outcomes from prior work. Full references available after NDA.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          {cases.map((c) => (
            <Card key={c.title} className="rounded-2xl border-slate-800 bg-slate-900/60">
              <CardContent className="p-6">
                <p className="text-slate-400 text-xs uppercase tracking-wide">{c.result}</p>
                <h3 className="mt-1 text-lg font-semibold">{c.title}</h3>
                <p className="mt-2 text-sm text-slate-300">{c.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      <Section id="about">
        <div className="grid lg:grid-cols-3 gap-10 items-start">
          <div className="lg:col-span-2">
            <h2 className="text-3xl md:text-4xl font-bold">Built by Operators</h2>
            <p className="mt-3 text-slate-300">
              We’ve run turnarounds, structured seller-finance deals, and built lean systems inside blue-collar and services businesses.
              Backgrounds include aviation ops, investigative work, and revenue operations. Expect direct, data-driven execution and simple dashboards your team will actually use.
            </p>
            <ul className="mt-6 space-y-2 text-sm">
              {[
                "Lean SOPs and training that outlive any hire",
                "Reporting cadence that prevents surprises",
                "Candid, owner-friendly communication"
              ].map((i) => (
                <li key={i} className="flex items-center gap-2 text-slate-300">
                  <Users2 className="w-4 h-4" />{i}
                </li>
              ))}
            </ul>
          </div>
          <Card className="rounded-2xl border-slate-800 bg-slate-900/60">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold">Snapshot</h3>
              <ul className="mt-4 space-y-2 text-sm">
                {[
                  "Florida-based; serving U.S.",
                  "Typical engagement: 6-12 months",
                  "Sweet spot: $1-10M revenue",
                  "Fast wins in 30 days"
                ].map((i) => (
                  <li key={i} className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4" />{i}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </Section>

      <Section id="contact">
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-bold">Request a Strategy Call</h2>
          <p className="mt-3 text-slate-300">Tell us about your targets and bottlenecks. We’ll respond within one business day.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 mt-8">
          <form action="https://formspree.io/f/REPLACE_ME" method="POST" className="md:col-span-2 space-y-3">
            <input type="hidden" name="_subject" value="NorthStar Website Inquiry" />
            <div className="grid sm:grid-cols-2 gap-3">
              <Input name="name" placeholder="Full name" required className="rounded-2xl bg-slate-900/60 border-slate-800" />
              <Input name="email" placeholder="Email" type="email" required className="rounded-2xl bg-slate-900/60 border-slate-800" />
            </div>
            <Input name="company" placeholder="Company" className="rounded-2xl bg-slate-900/60 border-slate-800" />
            <Textarea name="message" placeholder="What are you trying to accomplish in the next 12 months?" rows={5} className="rounded-2xl bg-slate-900/60 border-slate-800" />
            <button type="submit" className="inline-flex items-center justify-center h-10 px-4 rounded-xl bg-slate-100 text-slate-900 hover:bg-white font-medium">Send</button>
          </form>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 mt-1" />
              <div>
                <p className="font-semibold">(239) 313-1841</p>
                <p className="text-sm text-slate-300">Mon-Fri, 9a-5p ET</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 mt-1" />
              <div>
                <p className="font-semibold">partners@northstaroperationsgroup.com</p>
                <p className="text-sm text-slate-300">Secure email preferred</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 mt-1" />
              <div>
                <p className="font-semibold">Southwest Florida</p>
                <p className="text-sm text-slate-300">Serving clients nationwide</p>
              </div>
            </div>
          </div>
        </div>
      </Section>

      <footer className="border-t border-slate-800 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-400">
          <p>(c) {new Date().getFullYear()} NorthStar Operations Group. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#services" className="hover:text-slate-200">Services</a>
            <a href="#about" className="hover:text-slate-200">About</a>
            <a href="#contact" className="hover:text-slate-200">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
