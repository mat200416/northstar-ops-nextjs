import * as React from "react";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "secondary" | "ghost";
  size?: "default" | "lg" | "sm";
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className = "", variant = "default", size = "default", ...props }, ref) => {
    const base =
      "inline-flex items-center justify-center font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none";
    const variants: Record<string, string> = {
      default: "bg-slate-100 text-slate-900 hover:bg-white focus:ring-slate-400",
      secondary: "bg-slate-800 text-slate-100 hover:bg-slate-700 focus:ring-slate-600",
      ghost: "bg-transparent text-slate-100 hover:bg-slate-800/60 focus:ring-slate-600"
    };
    const sizes: Record<string, string> = {
      sm: "h-8 px-3 text-sm rounded-lg",
      default: "h-10 px-4 rounded-xl",
      lg: "h-12 px-6 text-base rounded-2xl"
    };

    return (
      <button
        ref={ref}
        className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
