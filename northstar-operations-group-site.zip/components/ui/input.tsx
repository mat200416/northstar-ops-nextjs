import * as React from "react";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className = "", ...props }, ref) => {
    const base =
      "w-full h-11 px-3 rounded-xl bg-slate-900/60 border border-slate-800 placeholder:text-slate-400 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-600";
    return <input ref={ref} className={`${base} ${className}`} {...props} />;
  }
);
Input.displayName = "Input";
