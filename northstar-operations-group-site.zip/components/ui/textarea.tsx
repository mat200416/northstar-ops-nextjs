import * as React from "react";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className = "", rows = 4, ...props }, ref) => {
    const base =
      "w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800 placeholder:text-slate-400 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-600";
    return <textarea ref={ref} rows={rows} className={`${base} ${className}`} {...props} />;
  }
);
Textarea.displayName = "Textarea";
